# Fujitsu Enterprise Postgres Operator for Kubernetes Helm Chart

Fujitsu Enterprise Postgres delivers an enterprise-grade PostgreSQL in Kubernetes. This solution provides the flexibility of a hybrid cloud solution with operational simplicity, while delivering an enhanced distribution of PostgreSQL to support enterprise-level workloads and provide improved deployment and management, availability, performance, data governance and security.

The download and Use of the Product is strictly subject to the terms of the End User License Agreement with Fujitsu Limited found at https://www.fast.fujitsu.com/fujitsu-enterprise-postgres-license-agreements. Where the Product that has been embedded as a whole or part into a third party program, only Authorised Customers may download and use the Product.


## Supported platforms

Depending on the version of the Fujitsu Enterprise Postgres Operator, it supports the following platforms:

| Helm Chart version    | Kubernetes                    | Architecture          |
|-----------------------|-------------------------------|-----------------------|
| v1.1.0                | 1.21, 1.22                    | amd64                 |
| v1.1.2                | 1.21, 1.22                    | amd64                 |
| v1.1.3                | 1.21, 1.22, 1.23              | amd64                 |
| v1.1.4                | 1.21, 1.22, 1.23              | amd64                 |
| v1.1.5                | 1.21, 1.22, 1.23              | amd64                 |
| v1.1.6                | 1.21, 1.22, 1.23              | amd64                 |
| v1.1.7                | 1.21, 1.22, 1.23              | amd64                 |
| v1.1.8                | 1.21, 1.22, 1.23              | amd64                 |
| v1.1.10               | 1.21, 1.22, 1.23              | amd64                 |
| v1.1.11               | 1.21, 1.22, 1.23              | amd64                 |
| v1.1.12               | 1.21, 1.22, 1.23              | amd64                 |
| v2.1.0                | 1.21, 1.22, 1.23, 1.24        | amd64, s390x          |
| v2.1.1                | 1.21, 1.22, 1.23, 1.24        | amd64, s390x          |
| v2.1.2                | 1.21, 1.22, 1.23, 1.24        | amd64, s390x          |
| v2.1.3                | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.1.4                | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.1.5                | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.1.6                | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.1.7                | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.1.8                | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.1.9                | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.1.10               | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.2.0                | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.2.1                | 1.24, 1.25, 1.26              | amd64, s390x          |
| v2.2.2                | 1.25, 1.26, 1.27              | amd64, s390x          |
| v2.2.3                | 1.25, 1.26, 1.27              | amd64, s390x          |
| v2.2.4                | 1.25, 1.26, 1.27              | amd64, s390x          |
| v2.2.5                | 1.25, 1.26, 1.27              | amd64, s390x          |
| v2.2.6                | 1.25, 1.26, 1.27              | amd64, s390x          |
| v3.1.0                | 1.25, 1.26, 1.27              | amd64, s390x          |
| v3.1.1                | 1.25, 1.26, 1.27              | amd64, s390x          |
| v3.1.2                | 1.25, 1.26, 1.27              | amd64, s390x          |
| v3.1.3                | 1.25, 1.26, 1.27              | amd64, s390x          |
| v3.2.0                | 1.25, 1.26, 1.27, 1.28        | amd64, s390x          |
| v3.2.1                | 1.25, 1.26, 1.27, 1.28        | amd64, s390x          |
| v4.1.0                | 1.27, 1.28, 1.29              | amd64, s390x          |
| v4.1.1                | 1.27, 1.28, 1.29              | amd64, s390x          |
| v4.1.2                | 1.27, 1.28, 1.29              | amd64, s390x          |
| v4.2.0                | 1.27, 1.28, 1.29, 1.30        | amd64, s390x          |
| v4.2.1                | 1.27, 1.28, 1.29, 1.30        | amd64, s390x          |
| v4.2.2                | 1.27, 1.28, 1.29, 1.30        | amd64, s390x          |
| v4.2.3                | 1.27, 1.28, 1.29, 1.30, 1.31  | amd64, s390x          |
| v4.2.4                | 1.27, 1.28, 1.29, 1.30, 1.31  | amd64, s390x          |
| v4.2.5                | 1.27, 1.28, 1.29, 1.30, 1.31  | amd64, s390x          |
| v4.3.0                | 1.27, 1.29, 1.30, 1.31, 1.32  | amd64, s390x          |
| v4.3.1                | 1.27, 1.29, 1.30, 1.31, 1.32  | amd64, s390x          |
| v5.1.0                | 1.27, 1.29, 1.30, 1.31, 1.32  | amd64                 |
| v5.1.1                | 1.27, 1.29, 1.30, 1.31, 1.32  | amd64                 |
| v5.2.0                | 1.27, 1.29, 1.30, 1.31, 1.32, 1.33  | amd64                 |

## Quick Start

The Fujitsu Enterprise Postgres Operator can be installed in any namespace to manage the lifecycle of a Postgres cluster using Fujitsu Enterprise Postgres Server within that namespace. It holds the operator deployment and all dependent
objects like permissions, custom resources and corresponding StatefulSets.

### Installation

To create the namespace and deploy the operator, run the following commands

```sh
$ kubectl create namespace fep
$ helm repo add fep https://fujitsu.github.io/fep-operator-helm/v1
$ helm repo update 
$ helm install fep-operator fep/fujitsu-enterprise-postgres-operator -n fep
```

These commands deploy Fujitsu Enterprise Postgres Operator on the Kubernetes cluster.

For details on how to deploy a FEPcluster using the installed Operator, please check the documentation at https://www.postgresql.fastware.com/product-manuals#VersionForK8s

## Uninstalling the Chart

To uninstall/delete the `fep-operator-release` deployment:

```sh
$ helm uninstall fep-operator
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## License information

Please note that the Fujitsu Enterprise Postgres Operator installed with this Helm Chart must be purchased and use a product license.
